#include <bits/stdc++.h>
using namespace std;

bool hasEulerianCircuit(vector<map<int, int>>& adjList) {
    int n = adjList.size();
    
    for (int i = 0; i < n; i++) {
        if (adjList[i].size() % 2 != 0) {
            return false;
        }
    }
    
    return true;
}

vector<int> findEulerCircuit(vector<map<int, int>> adjList) {
    int n = adjList.size();
    
    if (!hasEulerianCircuit(adjList)) {
        cout << "Khong ton tai chu trinh Euler" << endl;
        return {};
    }
    
    stack<int> st;
    vector<int> circuit;
    
    int currentVertex = 0;
    st.push(currentVertex);
    
    while (!st.empty()) {
        currentVertex = st.top();
        
        if (!adjList[currentVertex].empty()) {
            auto it = adjList[currentVertex].begin();
            int neighbor = it->first;
            
            st.push(neighbor);
            
            adjList[currentVertex].erase(neighbor);
            adjList[neighbor].erase(currentVertex);
        } else {
            circuit.push_back(currentVertex);
            st.pop();
        }
    }
    
    return circuit;
}

void printCircuit(vector<int>& circuit) {
    if (circuit.empty()) {
        return;
    }
    
    for (int i = 0; i < circuit.size(); i++) {
        cout << circuit[i];
        if (i < circuit.size() - 1) {
            cout << " ";
        }
    }
    cout << endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int n;
    cin >> n;
    
    vector<map<int, int>> adjList(n);
    
    for (int i = 0; i < n; i++) {
        int k;
        cin >> k;
        for (int j = 0; j < k; j++) {
            int neighbor;
            cin >> neighbor;
            adjList[i][neighbor]++;
        }
    }
    
    vector<int> circuit = findEulerCircuit(adjList);
    printCircuit(circuit);
    
    return 0;
}