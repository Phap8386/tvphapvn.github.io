#include <bits/stdc++.h>
using namespace std;

bool hasEulerianCircuit(vector<vector<int>>& adjMatrix) {
    int n = adjMatrix.size();
    
    for (int i = 0; i < n; i++) {
        int degree = 0;
        for (int j = 0; j < n; j++) {
            degree += adjMatrix[i][j];
        }
        if (degree % 2 != 0) {
            return false;
        }
    }
    
    return true;
}

vector<int> findEulerCircuit(vector<vector<int>> adjMatrix) {
    int n = adjMatrix.size();
    
    if (!hasEulerianCircuit(adjMatrix)) {
        cout << "Khong ton tai chu trinh Euler" << endl;
        return {};
    }
    
    vector<vector<int>> tempMatrix = adjMatrix;
    
    stack<int> st;
    vector<int> circuit;
    
    int currentVertex = 0;
    st.push(currentVertex);
    
    while (!st.empty()) {
        currentVertex = st.top();
        
        bool found = false;
        for (int neighbor = 0; neighbor < n; neighbor++) {
            if (tempMatrix[currentVertex][neighbor] > 0) {
                st.push(neighbor);
                tempMatrix[currentVertex][neighbor]--;
                tempMatrix[neighbor][currentVertex]--;
                found = true;
                break;
            }
        }
        
        if (!found) {
            circuit.push_back(currentVertex);
            st.pop();
        }
    }
    
    return circuit;
}

void printCircuit(vector<int>& circuit) {
    if (circuit.empty()) {
        return;
    }
    
    for (int i = 0; i < circuit.size(); i++) {
        cout << circuit[i];
        if (i < circuit.size() - 1) {
            cout << " ";
        }
    }
    cout << endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int n;
    cin >> n;
    
    vector<vector<int>> adjMatrix(n, vector<int>(n));
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> adjMatrix[i][j];
        }
    }
    
    vector<int> circuit = findEulerCircuit(adjMatrix);
    printCircuit(circuit);
    
    return 0;
}