#include <bits/stdc++.h>
using namespace std;

bool hasEulerianCircuit(vector<vector<int>>& adjMatrix) {
    int n = adjMatrix.size();
    for (int i = 0; i < n; i++) {
        int degree = 0;
        for (int j = 0; j < n; j++) {
            degree += adjMatrix[i][j];
        }
        if (degree % 2 != 0) {
            return false;
        }
    }
    return true;
}

vector<int> findEulerCircuit(vector<vector<int>> adjMatrix) {
    int n = adjMatrix.size();
    vector<vector<int>> tempMatrix = adjMatrix;
    
    stack<int> st;
    vector<int> circuit;
    
    int currentVertex = 0;
    st.push(currentVertex);
    
    while (!st.empty()) {
        currentVertex = st.top();
        
        bool found = false;
        for (int neighbor = 0; neighbor < n; neighbor++) {
            if (tempMatrix[currentVertex][neighbor] > 0) {
                st.push(neighbor);
                tempMatrix[currentVertex][neighbor]--;
                tempMatrix[neighbor][currentVertex]--;
                found = true;
                break;
            }
        }
        
        if (!found) {
            circuit.push_back(currentVertex);
            st.pop();
        }
    }
    
    return circuit;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int n;
    cin >> n;
    
    vector<vector<int>> adjMatrix(n, vector<int>(n));
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> adjMatrix[i][j];
        }
    }
    
    if (!hasEulerianCircuit(adjMatrix)) {
        cout << "0\n";
        return 0;
    }
    
    vector<int> circuit = findEulerCircuit(adjMatrix);
    
    cout << "1\n";
    for (int i = 0; i < circuit.size(); i++) {
        cout << circuit[i] + 1;
        if (i < circuit.size() - 1) {
            cout << " ";
        }
    }
    cout << "\n";
    
    return 0;
}