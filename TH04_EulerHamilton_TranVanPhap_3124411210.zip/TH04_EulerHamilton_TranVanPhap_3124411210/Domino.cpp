#include <bits/stdc++.h>
using namespace std;

vector<vector<pair<int, int>>> adj; // lưu (đỉnh kề, chỉ số domino)
vector<bool> used;
vector<int> result;

void dfs(int u) {
    while (!adj[u].empty()) {
        auto [v, idx] = adj[u].back();
        adj[u].pop_back();
        
        if (!used[idx]) {
            used[idx] = true;
            dfs(v);
            result.push_back(idx);
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    
    int n;
    cin >> n;
    
    adj.resize(6);
    used.resize(n, false);
    
    vector<pair<int, int>> dominoes(n);
    
    for (int i = 0; i < n; i++) {
        int x, y;
        cin >> x >> y;
        dominoes[i] = {x, y};
        
        // Thêm cạnh vô hướng
        adj[x].push_back({y, i});
        adj[y].push_back({x, i});
    }
    
    // Kiểm tra điều kiện Euler: tất cả đỉnh phải có bậc chẵn
    bool hasEulerCycle = true;
    int start = -1;
    for (int i = 0; i < 6; i++) {
        if (!adj[i].empty()) {
            if (start == -1) start = i;
            if (adj[i].size() % 2 != 0) {
                hasEulerCycle = false;
                break;
            }
        }
    }
    
    // Kiểm tra tính liên thông
    if (hasEulerCycle && start != -1) {
        // Đếm số đỉnh có cạnh
        int vertexWithEdges = 0;
        for (int i = 0; i < 6; i++) {
            if (!adj[i].empty()) vertexWithEdges++;
        }
        
        // DFS để kiểm tra tính liên thông
        vector<bool> visited(6, false);
        stack<int> st;
        st.push(start);
        visited[start] = true;
        int count = 0;
        
        while (!st.empty()) {
            int u = st.top();
            st.pop();
            count++;
            
            for (auto [v, idx] : adj[u]) {
                if (!visited[v]) {
                    visited[v] = true;
                    st.push(v);
                }
            }
        }
        
        hasEulerCycle = (count == vertexWithEdges);
    }
    
    if (!hasEulerCycle || start == -1) {
        cout << "0\n";
        return 0;
    }
    
    // Tìm chu trình Euler
    dfs(start);
    
    // Kiểm tra xem đã dùng hết tất cả domino chưa
    if (result.size() != n) {
        cout << "0\n";
        return 0;
    }
    
    cout << "1\n";
    
    // In kết quả theo thứ tự ngược lại (vì DFS lưu ngược)
    reverse(result.begin(), result.end());
    
    for (int i = 0; i < n; i++) {
        int idx = result[i];
        int x = dominoes[idx].first;
        int y = dominoes[idx].second;
        
        // Xác định hướng đặt domino
        if (i == 0) {
            cout << x << " " << y << "\n";
        } else {
            int prev_idx = result[i-1];
            int prev_x = dominoes[prev_idx].first;
            int prev_y = dominoes[prev_idx].second;
            
            // Tìm số chung với domino trước
            if (prev_y == x) {
                cout << x << " " << y << "\n";
            } else if (prev_y == y) {
                cout << y << " " << x << "\n";
            } else if (prev_x == x) {
                cout << x << " " << y << "\n";
            } else {
                cout << y << " " << x << "\n";
            }
        }
    }
    
    return 0;
}