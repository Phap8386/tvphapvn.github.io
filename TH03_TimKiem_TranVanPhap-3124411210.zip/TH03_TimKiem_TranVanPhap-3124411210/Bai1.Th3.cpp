#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int main() {
    int n, x;
    cin >> n >> x;
    
    vector<vector<int>> adj(n + 1);
    
    for (int i = 1; i <= n; i++) {
        int j;
        while (cin >> j) {
            adj[i].push_back(j);
        }
    }
    
    vector<bool> visited(n + 1, false);
    vector<int> result;
    
    queue<int> q;
    q.push(x);
    visited[x] = true;
    
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        result.push_back(u);
        
        for (int v : adj[u]) {
            if (!visited[v]) {
                visited[v] = true;
                q.push(v);
            }
        }
    }
    
    sort(result.begin(), result.end());
    cout << result.size() << endl;
    for (size_t i = 0; i < result.size(); i++) {
        cout << result[i] << " ";
    }
    cout << endl;
    
    return 0;
}