#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int main() {
    int n, x, y;
    cin >> n >> x >> y;
    
    vector<vector<int>> adj(n + 1);
    
    for (int i = 1; i <= n; i++) {
        int j;
        while (cin >> j) {
            adj[i].push_back(j);
        }
    }
    
    vector<int> parent(n + 1, 0);
    vector<bool> visited(n + 1, false);
    
    queue<int> q;
    q.push(x);
    visited[x] = true;
    parent[x] = -1;
    
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        
        if (u == y) break;
        
        for (int v : adj[u]) {
            if (!visited[v]) {
                visited[v] = true;
                parent[v] = u;
                q.push(v);
            }
        }
    }
    
    if (!visited[y]) {
        cout << 0 << endl;
        return 0;
    }
    
    vector<int> path;
    int cur = y;
    while (cur != -1) {
        path.push_back(cur);
        cur = parent[cur];
    }
    
    reverse(path.begin(), path.end());
    cout << path.size() << endl;
    for (size_t i = 0; i < path.size(); i++) {
        cout << path[i] << " ";
    }
    cout << endl;
    
    return 0;
}