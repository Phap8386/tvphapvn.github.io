#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int main() {
    int n;
    cin >> n;
    
    vector<vector<int>> adj(n + 1);
    
    for (int i = 1; i <= n; i++) {
        int j;
        while (cin >> j) {
            adj[i].push_back(j);
        }
    }
    
    vector<bool> visited(n + 1, false);
    vector<vector<int>> components;
    
    for (int i = 1; i <= n; i++) {
        if (!visited[i]) {
            vector<int> component;
            queue<int> q;
            q.push(i);
            visited[i] = true;
            
            while (!q.empty()) {
                int u = q.front();
                q.pop();
                component.push_back(u);
                
                for (int v : adj[u]) {
                    if (!visited[v]) {
                        visited[v] = true;
                        q.push(v);
                    }
                }
            }
            
            sort(component.begin(), component.end());
            components.push_back(component);
        }
    }
    
    cout << components.size() << endl;
    for (auto& component : components) {
        for (size_t i = 0; i < component.size(); i++) {
            cout << component[i] << " ";
        }
        cout << endl;
    }
    
    return 0;
}