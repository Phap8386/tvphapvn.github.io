#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int countComponents(vector<vector<int>>& adj, int n, int excludeEdgeU = -1, int excludeEdgeV = -1, int excludeVertex = -1) {
    vector<bool> visited(n + 1, false);
    int count = 0;
    
    for (int i = 1; i <= n; i++) {
        if (i == excludeVertex) continue;
        
        if (!visited[i]) {
            count++;
            queue<int> q;
            q.push(i);
            visited[i] = true;
            
            while (!q.empty()) {
                int u = q.front();
                q.pop();
                
                for (int v : adj[u]) {
                    if (v == excludeVertex) continue;
                    if ((u == excludeEdgeU && v == excludeEdgeV) || (u == excludeEdgeV && v == excludeEdgeU)) continue;
                    if (!visited[v]) {
                        visited[v] = true;
                        q.push(v);
                    }
                }
            }
        }
    }
    
    return count;
}

int main() {
    int n, x, y, z;
    cin >> n >> x >> y >> z;
    
    vector<vector<int>> adj(n + 1);
    
    for (int i = 1; i <= n; i++) {
        int j;
        while (cin >> j) {
            adj[i].push_back(j);
        }
    }
    
    int originalComponents = countComponents(adj, n);
    int withoutEdgeComponents = countComponents(adj, n, x, y);
    
    if (withoutEdgeComponents > originalComponents) {
        cout << "canh cau" << endl;
    } else {
        cout << "khong la canh cau" << endl;
    }
    
    int withoutVertexComponents = countComponents(adj, n, -1, -1, z);
    
    if (withoutVertexComponents > originalComponents) {
        cout << "dinh khop" << endl;
    } else {
        cout << "khong la dinh khop" << endl;
    }
    
    return 0;
}