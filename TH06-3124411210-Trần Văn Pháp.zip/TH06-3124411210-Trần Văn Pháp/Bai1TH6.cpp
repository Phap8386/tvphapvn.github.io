#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <limits>
#include <fstream>
#include <iomanip>

using namespace std;

const double INF = numeric_limits<double>::max();

struct Circle {
    double x, y, r;
    Circle(double x = 0, double y = 0, double r = 0) : x(x), y(y), r(r) {}
};

struct Edge {
    int to;
    int jump; // 0: bước, 1: nhảy
    Edge(int t, int j) : to(t), jump(j) {}
};

struct State {
    int node;
    int total_jumps;
    int total_steps;
    State(int n, int tj, int ts) : node(n), total_jumps(tj), total_steps(ts) {}
    
    // So sánh cho priority_queue: ưu tiên jumps ít hơn, sau đó steps ít hơn
    bool operator>(const State& other) const {
        if (total_jumps != other.total_jumps)
            return total_jumps > other.total_jumps;
        return total_steps > other.total_steps;
    }
};

void solveCircle() {
    ifstream fin("CIRCLE.INP");
    ofstream fout("CIRCLE.OUT");
    
    int n, s, t;
    fin >> n >> s >> t;
    
    vector<Circle> circles(n + 1);
    for (int i = 1; i <= n; i++) {
        fin >> circles[i].x >> circles[i].y >> circles[i].r;
    }
    
    // Xây dựng đồ thị
    vector<vector<Edge>> graph(n + 1);
    
    for (int i = 1; i <= n; i++) {
        for (int j = i + 1; j <= n; j++) {
            double dist_center = sqrt(pow(circles[i].x - circles[j].x, 2) + 
                                    pow(circles[i].y - circles[j].y, 2));
            double gap = dist_center - (circles[i].r + circles[j].r);
            
            if (gap <= 50) {
                graph[i].push_back(Edge(j, 0));
                graph[j].push_back(Edge(i, 0));
            } else if (gap <= 60) {
                graph[i].push_back(Edge(j, 1));
                graph[j].push_back(Edge(i, 1));
            }
        }
    }
    
    // Dijkstra với 2 tiêu chí
    vector<int> jumps(n + 1, INT_MAX);
    vector<int> steps(n + 1, INT_MAX);
    vector<pair<int, int>> parent(n + 1, {-1, -1}); // {parent, jump_type}
    
    jumps[s] = 0;
    steps[s] = 1;
    
    priority_queue<State, vector<State>, greater<State>> pq;
    pq.push(State(s, 0, 1));
    
    while (!pq.empty()) {
        State current = pq.top();
        pq.pop();
        
        int u = current.node;
        int curr_jumps = current.total_jumps;
        int curr_steps = current.total_steps;
        
        if (u == t) break;
        
        // Nếu state không tối ưu, bỏ qua
        if (curr_jumps > jumps[u] || (curr_jumps == jumps[u] && curr_steps > steps[u]))
            continue;
        
        for (const Edge& edge : graph[u]) {
            int v = edge.to;
            int new_jumps = curr_jumps + edge.jump;
            int new_steps = curr_steps + 1;
            
            if (new_jumps < jumps[v] || (new_jumps == jumps[v] && new_steps < steps[v])) {
                jumps[v] = new_jumps;
                steps[v] = new_steps;
                parent[v] = {u, edge.jump};
                pq.push(State(v, new_jumps, new_steps));
            }
        }
    }
    
    // Xuất kết quả
    if (jumps[t] == INT_MAX) {
        fout << 0 << endl;
    } else {
        fout << 1 << endl;
        fout << jumps[t] << " " << steps[t] << endl;
        
        // Truy vết đường đi
        vector<pair<int, int>> path;
        int current = t;
        while (current != s) {
            path.push_back({current, parent[current].second});
            current = parent[current].first;
        }
        path.push_back({s, 0});
        
        // In ngược từ start đến end
        for (int i = path.size() - 1; i >= 0; i--) {
            fout << path[i].first << " " << path[i].second << endl;
        }
    }
    
    fin.close();
    fout.close();
}

int main() {
    solveCircle();
    return 0;
}