#include <iostream>
#include <vector>
#include <queue>
#include <limits>
#include <fstream>
#include <algorithm>

using namespace std;

const int INF = numeric_limits<int>::max();

struct Point {
    int x, y;
    Point(int x = 0, int y = 0) : x(x), y(y) {}
};

struct State {
    int cost;
    int x, y;
    State(int c, int x, int y) : cost(c), x(x), y(y) {}
    
    bool operator>(const State& other) const {
        return cost > other.cost;
    }
};

void solveMintable() {
    ifstream fin("MINTABLE.INP");
    ofstream fout("MINTABLE.OUT");
    
    int n, m, xi, yi, xj, yj;
    fin >> n >> m >> xi >> yi >> xj >> yj;
    
    vector<vector<int>> grid(n, vector<int>(m));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            fin >> grid[i][j];
        }
    }
    
    // Chuyển về index 0-based
    xi--; yi--; xj--; yj--;
    
    // Kiểm tra ô bắt đầu và kết thúc
    if (grid[xi][yi] == 0 || grid[xj][yj] == 0) {
        fout << 0 << endl;
        fin.close();
        fout.close();
        return;
    }
    
    // Khởi tạo
    vector<vector<int>> dist(n, vector<int>(m, INF));
    vector<vector<Point>> parent(n, vector<Point>(m, {-1, -1}));
    
    // 4 hướng di chuyển
    int dx[] = {0, 1, 0, -1};
    int dy[] = {1, 0, -1, 0};
    
    dist[xi][yi] = 0;
    priority_queue<State, vector<State>, greater<State>> pq;
    pq.push(State(0, xi, yi));
    
    while (!pq.empty()) {
        State current = pq.top();
        pq.pop();
        
        int cost = current.cost;
        int x = current.x;
        int y = current.y;
        
        if (x == xj && y == yj) break;
        
        // Nếu state không tối ưu
        if (cost > dist[x][y]) continue;
        
        for (int i = 0; i < 4; i++) {
            int nx = x + dx[i];
            int ny = y + dy[i];
            
            if (nx >= 0 && nx < n && ny >= 0 && ny < m && grid[nx][ny] != 0) {
                int new_cost = cost;
                
                // Không tính chi phí cho ô kết thúc
                if (!(nx == xj && ny == yj)) {
                    new_cost += grid[nx][ny];
                }
                
                if (new_cost < dist[nx][ny]) {
                    dist[nx][ny] = new_cost;
                    parent[nx][ny] = {x, y};
                    pq.push(State(new_cost, nx, ny));
                }
            }
        }
    }
    
    // Xuất kết quả
    if (dist[xj][yj] == INF) {
        fout << 0 << endl;
    } else {
        fout << 1 << endl;
        fout << dist[xj][yj] << endl;
        
        // Truy vết đường đi
        vector<Point> path;
        Point current(xj, yj);
        
        while (!(current.x == xi && current.y == yi)) {
            path.push_back(current);
            current = parent[current.x][current.y];
        }
        path.push_back(Point(xi, yi));
        
        // In từ start đến end
        reverse(path.begin(), path.end());
        for (const Point& p : path) {
            fout << p.x + 1 << " " << p.y + 1 << endl;
        }
    }
    
    fin.close();
    fout.close();
}

int main() {
    solveMintable();
    return 0;
}